# Derivadas-de-Estabilidade

Código de estimativa das derivadas de estabilidade de uma aeronave convencional.
